import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext.tsx';
import { SpinnerIcon } from '../components/icons.tsx';
import { useToast } from '../contexts/ToastContext.tsx';

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const { login, isAuthenticated } = useUser();
    const navigate = useNavigate();
    const { showToast } = useToast();

    React.useEffect(() => {
        if (isAuthenticated) {
            navigate('/');
        }
    }, [isAuthenticated, navigate]);

    const [isExiting, setIsExiting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await login(email, password);
            // Sucesso: Iniciar animação de saída e manter loading state
            setIsExiting(true);
            setTimeout(() => {
                navigate('/');
            }, 400);
        } catch (error: any) {
            setLoading(false);
            showToast(error.message || 'Falha no login.', 'error');
        }
    };

    const inputClasses = "w-full px-4 py-2 border rounded-md bg-transparent border-border focus:ring-2 focus:ring-accent focus:border-transparent transition";

    return (
        <div className={`space-y-6 transition-all duration-500 ease-in-out transform ${isExiting ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
            <div>
                <h2 className="text-2xl font-bold text-center text-primary">Acessar sua conta</h2>
                <p className="text-sm text-center text-muted mt-1">
                    Não tem uma conta?{' '}
                    <Link to="/register" className="font-medium text-accent hover:underline">
                        Cadastre-se
                    </Link>
                </p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-primary mb-1">Email</label>
                    <input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className={inputClasses}
                        required
                        placeholder="seu@email.com"
                    />
                </div>
                <div>
                    <label htmlFor="password-login" className="block text-sm font-medium text-primary mb-1">Senha</label>
                    <input
                        id="password-login"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className={inputClasses}
                        required
                        placeholder="••••••••"
                    />
                </div>
                <button
                    type="submit"
                    disabled={loading || isExiting}
                    className="w-full px-4 py-2.5 bg-primary text-on-primary rounded-md font-semibold hover:bg-opacity-90 transition disabled:bg-muted flex items-center justify-center"
                >
                    {(loading || isExiting) ? <SpinnerIcon className="h-5 w-5" /> : 'Entrar'}
                </button>
            </form>
        </div>
    );
};

export default Login;
