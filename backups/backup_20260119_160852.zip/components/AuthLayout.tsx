import React from 'react';
import { Outlet } from 'react-router-dom';

const AuthLayout: React.FC = () => {
    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-300 via-purple-300 to-pink-300 flex flex-col justify-center items-center p-4">
            <div className="mb-8 flex flex-col items-center gap-3">
                <img src="/logo.png" alt="iStore" className="h-32 object-contain" />
            </div>
            <div className="w-full max-w-sm">
                <div className="bg-white/80 backdrop-blur-lg p-8 rounded-2xl shadow-xl border border-white/50">
                    <Outlet />
                </div>
            </div>
        </div>
    );
};

export default AuthLayout;
