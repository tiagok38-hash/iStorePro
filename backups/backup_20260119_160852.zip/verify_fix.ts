
import { supabase } from './supabaseClient.ts';

async function run() {
    try {
        console.log('Fetching 1 customer with select(*)...');
        const { data, error } = await supabase.from('customers').select('*').limit(1);

        if (error) {
            console.error('Error:', error);
        } else {
            console.log('Success!');
            if (data && data.length > 0) {
                console.log('Customer Keys:', Object.keys(data[0]));
            } else {
                console.log('No customers found, but query worked.');
            }
        }
    } catch (e) {
        console.error('Exception:', e);
    }
}

run();
