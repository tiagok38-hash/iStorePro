import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function testFetch() {
    console.log("--- Testing Customer Fetch ---");

    const { data, error } = await supabase.from('customers').select('*');

    if (error) {
        console.error("[❌] Error fetching customers:");
        console.error("    Code:", error.code);
        console.error("    Message:", error.message);
        console.error("    Details:", error.details);

        if (error.code === '42501' || error.message.includes('permission denied')) {
            console.log("\n    -> DIAGNOSIS: RLS is blocking the SELECT. You need to add a policy.");
        }
    } else {
        console.log("[✅] Success! Fetched customers:", data?.length || 0);
        if (data && data.length > 0) {
            console.log("    First customer:", data[0]);
        }
    }
}

testFetch();
