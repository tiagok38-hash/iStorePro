
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkProductCost() {
    console.log('Searching for product iPhone 17 Pro Max...');

    // Find Product
    const { data: products, error } = await supabase
        .from('products')
        .select('*')
        .ilike('model', '%iPhone 17 Pro Max%');

    if (error) {
        console.error('Error fetching product:', error);
        return;
    }

    if (!products || products.length === 0) {
        console.log('Product not found.');
        return;
    }

    for (const p of products) {
        console.log('----------------------------');
        console.log(`Model: ${p.model}`);
        console.log(`Cost Price: ${p.costPrice}`);
        console.log(`Price: ${p.price}`);
        console.log(`Additional Cost: ${p.additionalCostPrice}`);
    }
}

checkProductCost();
